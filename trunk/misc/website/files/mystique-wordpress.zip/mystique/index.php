<?php

// Templates are located in the /templates/ directory