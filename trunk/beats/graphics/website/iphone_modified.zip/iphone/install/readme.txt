Quick Install

1. Unzip the phpbb-iphone-style template (if you are reading this you've probably already done that
2. Copy the iphone folder into your sites styles/ directory.
3. Login to your sites ACP, and install the iphone theme.
4. Make a note of the id given to the style (hover over the Details link for the theme, and look at the end of the url)
5. Enable automatic detection of mobile browsers by following the instructions in browser_redirection_code
