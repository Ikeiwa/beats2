#
# @Created by (c) gokinstudio.com MiXon.biz
# @package phpBB3
# @copyright (c) 2005 phpBB Group 		
# @License: http://opensource.org/licenses/gpl-license.php GNU General Public License v2 
#
#
# Style have 17 language pack
# 
# English (en) language pack
# Czech (cz) language pack
# German (de) language pack
# Danish (dk) language pack
# Spanish (es) language pack
# French (fr) language pack
# Croatian (hr) language pack
# Hungarian (hu) language pack
# Indonesian (id) language pack
# Italian (it) language pack
# Dutch (nl) language pack
# Norwegian (no) language pack
# Polish (pl) language pack
# Portuguese (pt-br) language pack
# Slovak (sk) language pack
# Swedish (sv) language pack
# Turkish (tr) language pack
#
# @Everythings is in folder imageset.
# 
# NOTE !!!
# IF YOU DON'T USE OTHER LANGUAGE PACK DELETE THEM ! 
#
# Question ? gok4in@gmail.com 
# gokinstudio.com