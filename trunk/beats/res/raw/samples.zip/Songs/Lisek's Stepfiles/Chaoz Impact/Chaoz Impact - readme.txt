Hi there!
Here it comes, new StepMix entry by Lisek, Chaoz Impact by ParagonX9 grabbed from newgrounds with CC license.
Graphics are by Najezony, visit his digiart for more of his works ( http://najezony.digart.pl/ ).
The song is a breakbeat masterpiece by everyone's favourite musican, ParagonX9.
Just like my previous works, every chart is quality-checked by Chmurek, the StepMix3 winner (the creator of Rockhill).

[Beginner][1]
Easy breakbeat beginner.

[Light][3]
Easy patterns, not really tiring.

[Standard][6]
In this chart I used the steps that match the acid beat, even though it is standard it is pretty challenging.

[Heavy][8]
A mix of acid and breakbeat style. Many streams and many holds. Also, beware of the mines. Does this chart work? Yeah, pretty much.


